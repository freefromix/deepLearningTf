"""Gan tutorial"""

# https://www.oreilly.com/learning/generative-adversarial-networks-for-beginners

import tensorflow as tf
import numpy as np
import datetime
import matplotlib.pyplot as plt

%matplotlib inline

from tensorflow.